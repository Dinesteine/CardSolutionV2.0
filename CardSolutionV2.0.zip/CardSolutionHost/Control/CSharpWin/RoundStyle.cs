﻿namespace CSharpWin
{
    using System;

    public enum RoundStyle
    {
        None,
        All,
        Left,
        Right,
        Top,
        Bottom
    }
}

