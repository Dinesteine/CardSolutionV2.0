﻿using System;
namespace CSharpWin
{
    internal enum ControlState
    {
        Normal,
        Hover,
        Pressed,
        Focused
    }
}

