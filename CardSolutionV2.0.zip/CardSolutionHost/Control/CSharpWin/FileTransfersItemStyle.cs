﻿namespace CSharpWin
{
    using System;

    public enum FileTransfersItemStyle
    {
        Send,
        ReadyReceive,
        Receive
    }
}

