﻿using System;

namespace CardSolutionHost
{
    partial class NavigationWorkForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.appContainer30 = new CardSolutionHost.Control.AppContainer();
            this.appContainer24 = new CardSolutionHost.Control.AppContainer();
            this.appContainer18 = new CardSolutionHost.Control.AppContainer();
            this.appContainer12 = new CardSolutionHost.Control.AppContainer();
            this.appContainer35 = new CardSolutionHost.Control.AppContainer();
            this.appContainer29 = new CardSolutionHost.Control.AppContainer();
            this.appContainer23 = new CardSolutionHost.Control.AppContainer();
            this.appContainer17 = new CardSolutionHost.Control.AppContainer();
            this.appContainer11 = new CardSolutionHost.Control.AppContainer();
            this.appContainer34 = new CardSolutionHost.Control.AppContainer();
            this.appContainer28 = new CardSolutionHost.Control.AppContainer();
            this.appContainer22 = new CardSolutionHost.Control.AppContainer();
            this.appContainer16 = new CardSolutionHost.Control.AppContainer();
            this.appContainer10 = new CardSolutionHost.Control.AppContainer();
            this.appContainer33 = new CardSolutionHost.Control.AppContainer();
            this.appContainer27 = new CardSolutionHost.Control.AppContainer();
            this.appContainer21 = new CardSolutionHost.Control.AppContainer();
            this.appContainer15 = new CardSolutionHost.Control.AppContainer();
            this.appContainer9 = new CardSolutionHost.Control.AppContainer();
            this.appContainer32 = new CardSolutionHost.Control.AppContainer();
            this.appContainer31 = new CardSolutionHost.Control.AppContainer();
            this.appContainer26 = new CardSolutionHost.Control.AppContainer();
            this.appContainer25 = new CardSolutionHost.Control.AppContainer();
            this.appContainer20 = new CardSolutionHost.Control.AppContainer();
            this.appContainer19 = new CardSolutionHost.Control.AppContainer();
            this.appContainer14 = new CardSolutionHost.Control.AppContainer();
            this.appContainer13 = new CardSolutionHost.Control.AppContainer();
            this.appContainer8 = new CardSolutionHost.Control.AppContainer();
            this.appContainer7 = new CardSolutionHost.Control.AppContainer();
            this.appContainer6 = new CardSolutionHost.Control.AppContainer();
            this.appContainer5 = new CardSolutionHost.Control.AppContainer();
            this.appContainer4 = new CardSolutionHost.Control.AppContainer();
            this.appContainer3 = new CardSolutionHost.Control.AppContainer();
            this.appContainer2 = new CardSolutionHost.Control.AppContainer();
            this.appContainer1 = new CardSolutionHost.Control.AppContainer();
            this.SuspendLayout();
            // 
            // appContainer30
            // 
            this.appContainer30.BackColor = System.Drawing.Color.Transparent;
            this.appContainer30.Location = new System.Drawing.Point(541, 370);
            this.appContainer30.Name = "appContainer30";
            this.appContainer30.Runner = null;
            this.appContainer30.Size = new System.Drawing.Size(126, 65);
            this.appContainer30.TabIndex = 11;
            // 
            // appContainer24
            // 
            this.appContainer24.BackColor = System.Drawing.Color.Transparent;
            this.appContainer24.Location = new System.Drawing.Point(409, 299);
            this.appContainer24.Name = "appContainer24";
            this.appContainer24.Runner = null;
            this.appContainer24.Size = new System.Drawing.Size(126, 65);
            this.appContainer24.TabIndex = 11;
            // 
            // appContainer18
            // 
            this.appContainer18.BackColor = System.Drawing.Color.Transparent;
            this.appContainer18.Location = new System.Drawing.Point(277, 228);
            this.appContainer18.Name = "appContainer18";
            this.appContainer18.Runner = null;
            this.appContainer18.Size = new System.Drawing.Size(126, 65);
            this.appContainer18.TabIndex = 11;
            // 
            // appContainer12
            // 
            this.appContainer12.BackColor = System.Drawing.Color.Transparent;
            this.appContainer12.Location = new System.Drawing.Point(145, 157);
            this.appContainer12.Name = "appContainer12";
            this.appContainer12.Runner = null;
            this.appContainer12.Size = new System.Drawing.Size(126, 65);
            this.appContainer12.TabIndex = 11;
            // 
            // appContainer35
            // 
            this.appContainer35.BackColor = System.Drawing.Color.Transparent;
            this.appContainer35.Location = new System.Drawing.Point(541, 441);
            this.appContainer35.Name = "appContainer35";
            this.appContainer35.Runner = null;
            this.appContainer35.Size = new System.Drawing.Size(126, 65);
            this.appContainer35.TabIndex = 10;
            // 
            // appContainer29
            // 
            this.appContainer29.BackColor = System.Drawing.Color.Transparent;
            this.appContainer29.Location = new System.Drawing.Point(409, 370);
            this.appContainer29.Name = "appContainer29";
            this.appContainer29.Runner = null;
            this.appContainer29.Size = new System.Drawing.Size(126, 65);
            this.appContainer29.TabIndex = 10;
            // 
            // appContainer23
            // 
            this.appContainer23.BackColor = System.Drawing.Color.Transparent;
            this.appContainer23.Location = new System.Drawing.Point(277, 299);
            this.appContainer23.Name = "appContainer23";
            this.appContainer23.Runner = null;
            this.appContainer23.Size = new System.Drawing.Size(126, 65);
            this.appContainer23.TabIndex = 10;
            // 
            // appContainer17
            // 
            this.appContainer17.BackColor = System.Drawing.Color.Transparent;
            this.appContainer17.Location = new System.Drawing.Point(145, 228);
            this.appContainer17.Name = "appContainer17";
            this.appContainer17.Runner = null;
            this.appContainer17.Size = new System.Drawing.Size(126, 65);
            this.appContainer17.TabIndex = 10;
            // 
            // appContainer11
            // 
            this.appContainer11.BackColor = System.Drawing.Color.Transparent;
            this.appContainer11.Location = new System.Drawing.Point(13, 157);
            this.appContainer11.Name = "appContainer11";
            this.appContainer11.Runner = null;
            this.appContainer11.Size = new System.Drawing.Size(126, 65);
            this.appContainer11.TabIndex = 10;
            // 
            // appContainer34
            // 
            this.appContainer34.BackColor = System.Drawing.Color.Transparent;
            this.appContainer34.Location = new System.Drawing.Point(409, 441);
            this.appContainer34.Name = "appContainer34";
            this.appContainer34.Runner = null;
            this.appContainer34.Size = new System.Drawing.Size(126, 65);
            this.appContainer34.TabIndex = 9;
            // 
            // appContainer28
            // 
            this.appContainer28.BackColor = System.Drawing.Color.Transparent;
            this.appContainer28.Location = new System.Drawing.Point(277, 370);
            this.appContainer28.Name = "appContainer28";
            this.appContainer28.Runner = null;
            this.appContainer28.Size = new System.Drawing.Size(126, 65);
            this.appContainer28.TabIndex = 9;
            // 
            // appContainer22
            // 
            this.appContainer22.BackColor = System.Drawing.Color.Transparent;
            this.appContainer22.Location = new System.Drawing.Point(145, 299);
            this.appContainer22.Name = "appContainer22";
            this.appContainer22.Runner = null;
            this.appContainer22.Size = new System.Drawing.Size(126, 65);
            this.appContainer22.TabIndex = 9;
            // 
            // appContainer16
            // 
            this.appContainer16.BackColor = System.Drawing.Color.Transparent;
            this.appContainer16.Location = new System.Drawing.Point(13, 228);
            this.appContainer16.Name = "appContainer16";
            this.appContainer16.Runner = null;
            this.appContainer16.Size = new System.Drawing.Size(126, 65);
            this.appContainer16.TabIndex = 9;
            // 
            // appContainer10
            // 
            this.appContainer10.BackColor = System.Drawing.Color.Transparent;
            this.appContainer10.Location = new System.Drawing.Point(541, 86);
            this.appContainer10.Name = "appContainer10";
            this.appContainer10.Runner = null;
            this.appContainer10.Size = new System.Drawing.Size(126, 65);
            this.appContainer10.TabIndex = 9;
            // 
            // appContainer33
            // 
            this.appContainer33.BackColor = System.Drawing.Color.Transparent;
            this.appContainer33.Location = new System.Drawing.Point(277, 441);
            this.appContainer33.Name = "appContainer33";
            this.appContainer33.Runner = null;
            this.appContainer33.Size = new System.Drawing.Size(126, 65);
            this.appContainer33.TabIndex = 8;
            // 
            // appContainer27
            // 
            this.appContainer27.BackColor = System.Drawing.Color.Transparent;
            this.appContainer27.Location = new System.Drawing.Point(145, 370);
            this.appContainer27.Name = "appContainer27";
            this.appContainer27.Runner = null;
            this.appContainer27.Size = new System.Drawing.Size(126, 65);
            this.appContainer27.TabIndex = 8;
            // 
            // appContainer21
            // 
            this.appContainer21.BackColor = System.Drawing.Color.Transparent;
            this.appContainer21.Location = new System.Drawing.Point(13, 299);
            this.appContainer21.Name = "appContainer21";
            this.appContainer21.Runner = null;
            this.appContainer21.Size = new System.Drawing.Size(126, 65);
            this.appContainer21.TabIndex = 8;
            // 
            // appContainer15
            // 
            this.appContainer15.BackColor = System.Drawing.Color.Transparent;
            this.appContainer15.Location = new System.Drawing.Point(541, 157);
            this.appContainer15.Name = "appContainer15";
            this.appContainer15.Runner = null;
            this.appContainer15.Size = new System.Drawing.Size(126, 65);
            this.appContainer15.TabIndex = 8;
            // 
            // appContainer9
            // 
            this.appContainer9.BackColor = System.Drawing.Color.Transparent;
            this.appContainer9.Location = new System.Drawing.Point(409, 86);
            this.appContainer9.Name = "appContainer9";
            this.appContainer9.Runner = null;
            this.appContainer9.Size = new System.Drawing.Size(126, 65);
            this.appContainer9.TabIndex = 8;
            // 
            // appContainer32
            // 
            this.appContainer32.BackColor = System.Drawing.Color.Transparent;
            this.appContainer32.Location = new System.Drawing.Point(145, 441);
            this.appContainer32.Name = "appContainer32";
            this.appContainer32.Runner = null;
            this.appContainer32.Size = new System.Drawing.Size(126, 65);
            this.appContainer32.TabIndex = 7;
            // 
            // appContainer31
            // 
            this.appContainer31.BackColor = System.Drawing.Color.Transparent;
            this.appContainer31.Location = new System.Drawing.Point(13, 441);
            this.appContainer31.Name = "appContainer31";
            this.appContainer31.Runner = null;
            this.appContainer31.Size = new System.Drawing.Size(126, 65);
            this.appContainer31.TabIndex = 6;
            // 
            // appContainer26
            // 
            this.appContainer26.BackColor = System.Drawing.Color.Transparent;
            this.appContainer26.Location = new System.Drawing.Point(13, 370);
            this.appContainer26.Name = "appContainer26";
            this.appContainer26.Runner = null;
            this.appContainer26.Size = new System.Drawing.Size(126, 65);
            this.appContainer26.TabIndex = 7;
            // 
            // appContainer25
            // 
            this.appContainer25.BackColor = System.Drawing.Color.Transparent;
            this.appContainer25.Location = new System.Drawing.Point(541, 299);
            this.appContainer25.Name = "appContainer25";
            this.appContainer25.Runner = null;
            this.appContainer25.Size = new System.Drawing.Size(126, 65);
            this.appContainer25.TabIndex = 6;
            // 
            // appContainer20
            // 
            this.appContainer20.BackColor = System.Drawing.Color.Transparent;
            this.appContainer20.Location = new System.Drawing.Point(541, 228);
            this.appContainer20.Name = "appContainer20";
            this.appContainer20.Runner = null;
            this.appContainer20.Size = new System.Drawing.Size(126, 65);
            this.appContainer20.TabIndex = 7;
            // 
            // appContainer19
            // 
            this.appContainer19.BackColor = System.Drawing.Color.Transparent;
            this.appContainer19.Location = new System.Drawing.Point(409, 228);
            this.appContainer19.Name = "appContainer19";
            this.appContainer19.Runner = null;
            this.appContainer19.Size = new System.Drawing.Size(126, 65);
            this.appContainer19.TabIndex = 6;
            // 
            // appContainer14
            // 
            this.appContainer14.BackColor = System.Drawing.Color.Transparent;
            this.appContainer14.Location = new System.Drawing.Point(409, 157);
            this.appContainer14.Name = "appContainer14";
            this.appContainer14.Runner = null;
            this.appContainer14.Size = new System.Drawing.Size(126, 65);
            this.appContainer14.TabIndex = 7;
            // 
            // appContainer13
            // 
            this.appContainer13.BackColor = System.Drawing.Color.Transparent;
            this.appContainer13.Location = new System.Drawing.Point(277, 157);
            this.appContainer13.Name = "appContainer13";
            this.appContainer13.Runner = null;
            this.appContainer13.Size = new System.Drawing.Size(126, 65);
            this.appContainer13.TabIndex = 6;
            // 
            // appContainer8
            // 
            this.appContainer8.BackColor = System.Drawing.Color.Transparent;
            this.appContainer8.Location = new System.Drawing.Point(277, 86);
            this.appContainer8.Name = "appContainer8";
            this.appContainer8.Runner = null;
            this.appContainer8.Size = new System.Drawing.Size(126, 65);
            this.appContainer8.TabIndex = 7;
            // 
            // appContainer7
            // 
            this.appContainer7.BackColor = System.Drawing.Color.Transparent;
            this.appContainer7.Location = new System.Drawing.Point(145, 86);
            this.appContainer7.Name = "appContainer7";
            this.appContainer7.Runner = null;
            this.appContainer7.Size = new System.Drawing.Size(126, 65);
            this.appContainer7.TabIndex = 6;
            // 
            // appContainer6
            // 
            this.appContainer6.BackColor = System.Drawing.Color.Transparent;
            this.appContainer6.Location = new System.Drawing.Point(13, 86);
            this.appContainer6.Name = "appContainer6";
            this.appContainer6.Runner = null;
            this.appContainer6.Size = new System.Drawing.Size(126, 65);
            this.appContainer6.TabIndex = 5;
            // 
            // appContainer5
            // 
            this.appContainer5.BackColor = System.Drawing.Color.Transparent;
            this.appContainer5.Location = new System.Drawing.Point(541, 12);
            this.appContainer5.Name = "appContainer5";
            this.appContainer5.Runner = null;
            this.appContainer5.Size = new System.Drawing.Size(126, 65);
            this.appContainer5.TabIndex = 4;
            // 
            // appContainer4
            // 
            this.appContainer4.BackColor = System.Drawing.Color.Transparent;
            this.appContainer4.Location = new System.Drawing.Point(409, 12);
            this.appContainer4.Name = "appContainer4";
            this.appContainer4.Runner = null;
            this.appContainer4.Size = new System.Drawing.Size(126, 65);
            this.appContainer4.TabIndex = 3;
            // 
            // appContainer3
            // 
            this.appContainer3.BackColor = System.Drawing.Color.Transparent;
            this.appContainer3.Location = new System.Drawing.Point(277, 12);
            this.appContainer3.Name = "appContainer3";
            this.appContainer3.Runner = null;
            this.appContainer3.Size = new System.Drawing.Size(126, 65);
            this.appContainer3.TabIndex = 2;
            // 
            // appContainer2
            // 
            this.appContainer2.BackColor = System.Drawing.Color.Transparent;
            this.appContainer2.Location = new System.Drawing.Point(145, 12);
            this.appContainer2.Name = "appContainer2";
            this.appContainer2.Runner = null;
            this.appContainer2.Size = new System.Drawing.Size(126, 65);
            this.appContainer2.TabIndex = 1;
            // 
            // appContainer1
            // 
            this.appContainer1.BackColor = System.Drawing.Color.Transparent;
            this.appContainer1.Location = new System.Drawing.Point(13, 12);
            this.appContainer1.Name = "appContainer1";
            this.appContainer1.Runner = null;
            this.appContainer1.Size = new System.Drawing.Size(126, 65);
            this.appContainer1.TabIndex = 0;
            // 
            // NavigationWorkForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(698, 530);
            this.Controls.Add(this.appContainer30);
            this.Controls.Add(this.appContainer24);
            this.Controls.Add(this.appContainer18);
            this.Controls.Add(this.appContainer12);
            this.Controls.Add(this.appContainer35);
            this.Controls.Add(this.appContainer29);
            this.Controls.Add(this.appContainer23);
            this.Controls.Add(this.appContainer17);
            this.Controls.Add(this.appContainer11);
            this.Controls.Add(this.appContainer34);
            this.Controls.Add(this.appContainer28);
            this.Controls.Add(this.appContainer22);
            this.Controls.Add(this.appContainer16);
            this.Controls.Add(this.appContainer10);
            this.Controls.Add(this.appContainer33);
            this.Controls.Add(this.appContainer27);
            this.Controls.Add(this.appContainer21);
            this.Controls.Add(this.appContainer15);
            this.Controls.Add(this.appContainer9);
            this.Controls.Add(this.appContainer32);
            this.Controls.Add(this.appContainer31);
            this.Controls.Add(this.appContainer26);
            this.Controls.Add(this.appContainer25);
            this.Controls.Add(this.appContainer20);
            this.Controls.Add(this.appContainer19);
            this.Controls.Add(this.appContainer14);
            this.Controls.Add(this.appContainer13);
            this.Controls.Add(this.appContainer8);
            this.Controls.Add(this.appContainer7);
            this.Controls.Add(this.appContainer6);
            this.Controls.Add(this.appContainer5);
            this.Controls.Add(this.appContainer4);
            this.Controls.Add(this.appContainer3);
            this.Controls.Add(this.appContainer2);
            this.Controls.Add(this.appContainer1);
            this.Name = "NavigationWorkForm";
            this.TabText = "我的工作导航";
            this.Text = "我的工作导航";
            this.Load += new System.EventHandler(this.NavigationWorkForm_Load);
            this.ResumeLayout(false);

        }
        #endregion
        private CardSolutionHost.Control.AppContainer appContainer1;
        private CardSolutionHost.Control.AppContainer appContainer2;
        private CardSolutionHost.Control.AppContainer appContainer4;
        private CardSolutionHost.Control.AppContainer appContainer3;
        private CardSolutionHost.Control.AppContainer appContainer6;
        private CardSolutionHost.Control.AppContainer appContainer5;
        private CardSolutionHost.Control.AppContainer appContainer12;
        private CardSolutionHost.Control.AppContainer appContainer11;
        private CardSolutionHost.Control.AppContainer appContainer10;
        private CardSolutionHost.Control.AppContainer appContainer9;
        private CardSolutionHost.Control.AppContainer appContainer8;
        private CardSolutionHost.Control.AppContainer appContainer7;
        private CardSolutionHost.Control.AppContainer appContainer13;
        private CardSolutionHost.Control.AppContainer appContainer14;
        private CardSolutionHost.Control.AppContainer appContainer15;
        private CardSolutionHost.Control.AppContainer appContainer16;
        private CardSolutionHost.Control.AppContainer appContainer17;
        private CardSolutionHost.Control.AppContainer appContainer18;
        private CardSolutionHost.Control.AppContainer appContainer19;
        private CardSolutionHost.Control.AppContainer appContainer20;
        private CardSolutionHost.Control.AppContainer appContainer21;
        private CardSolutionHost.Control.AppContainer appContainer22;
        private CardSolutionHost.Control.AppContainer appContainer23;
        private CardSolutionHost.Control.AppContainer appContainer24;
        private CardSolutionHost.Control.AppContainer appContainer25;
        private CardSolutionHost.Control.AppContainer appContainer26;
        private CardSolutionHost.Control.AppContainer appContainer27;
        private CardSolutionHost.Control.AppContainer appContainer28;
        private CardSolutionHost.Control.AppContainer appContainer29;
        private CardSolutionHost.Control.AppContainer appContainer30;
        private CardSolutionHost.Control.AppContainer appContainer31;
        private CardSolutionHost.Control.AppContainer appContainer32;
        private CardSolutionHost.Control.AppContainer appContainer33;
        private CardSolutionHost.Control.AppContainer appContainer34;
        private CardSolutionHost.Control.AppContainer appContainer35;
    }
}