﻿namespace CardSolutionHost.MenJin
{
    partial class acholidayEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbbholidayid = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCancle = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.dtpbegindate = new System.Windows.Forms.DateTimePicker();
            this.dtpenddate = new System.Windows.Forms.DateTimePicker();
            this.cbbtimezone = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbbholidayid
            // 
            this.cbbholidayid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbholidayid.FormattingEnabled = true;
            this.cbbholidayid.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.cbbholidayid.Location = new System.Drawing.Point(73, 5);
            this.cbbholidayid.Name = "cbbholidayid";
            this.cbbholidayid.Size = new System.Drawing.Size(60, 20);
            this.cbbholidayid.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "编号";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "开始日期";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "结束日期";
            // 
            // btnCancle
            // 
            this.btnCancle.Location = new System.Drawing.Point(164, 153);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.Size = new System.Drawing.Size(75, 23);
            this.btnCancle.TabIndex = 16;
            this.btnCancle.Text = "取消";
            this.btnCancle.UseVisualStyleBackColor = true;
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(27, 153);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 15;
            this.btnOK.Text = "确定";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // dtpbegindate
            // 
            this.dtpbegindate.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dtpbegindate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpbegindate.Location = new System.Drawing.Point(73, 78);
            this.dtpbegindate.Name = "dtpbegindate";
            this.dtpbegindate.Size = new System.Drawing.Size(166, 21);
            this.dtpbegindate.TabIndex = 17;
            // 
            // dtpenddate
            // 
            this.dtpenddate.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dtpenddate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpenddate.Location = new System.Drawing.Point(73, 115);
            this.dtpenddate.Name = "dtpenddate";
            this.dtpenddate.Size = new System.Drawing.Size(166, 21);
            this.dtpenddate.TabIndex = 18;
            // 
            // cbbtimezone
            // 
            this.cbbtimezone.FormattingEnabled = true;
            this.cbbtimezone.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.cbbtimezone.Location = new System.Drawing.Point(73, 41);
            this.cbbtimezone.Name = "cbbtimezone";
            this.cbbtimezone.Size = new System.Drawing.Size(60, 20);
            this.cbbtimezone.TabIndex = 20;
            this.cbbtimezone.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 19;
            this.label4.Text = "时间段";
            this.label4.Visible = false;
            // 
            // acholidayEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 183);
            this.Controls.Add(this.cbbtimezone);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtpenddate);
            this.Controls.Add(this.dtpbegindate);
            this.Controls.Add(this.btnCancle);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbbholidayid);
            this.Controls.Add(this.label1);
            this.Name = "acholidayEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.TabText = "节假日设置";
            this.Text = "节假日设置";
            this.Load += new System.EventHandler(this.acholidayEdit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbbholidayid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCancle;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.DateTimePicker dtpbegindate;
        private System.Windows.Forms.DateTimePicker dtpenddate;
        private System.Windows.Forms.ComboBox cbbtimezone;
        private System.Windows.Forms.Label label4;
    }
}