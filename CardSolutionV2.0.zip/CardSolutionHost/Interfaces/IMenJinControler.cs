﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CardSolutionHost.Interfaces
{
    public interface IMenJinControler
    {
        void RunRefreshMachine();
        void RunReloadMachine();
        List<IMenJinRunner> Runners { get; }
    }
}
