﻿namespace P2P.WellKnown.S2C
{
    using System;

    [Serializable]
    public class MassMsgResponseMessage : SCMessage
    {
    }
}

