﻿namespace P2P.WellKnown.P2P
{
    using System;

    [Serializable]
    public class TrashMessage : PPMessage
    {
    }
}

