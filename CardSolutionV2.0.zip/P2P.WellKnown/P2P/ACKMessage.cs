﻿namespace P2P.WellKnown.P2P
{
    using System;
    /// <summary>
    /// 测试应答消息
    /// </summary>
    [Serializable]
    public class ACKMessage : PPMessage
    {
    }
}

