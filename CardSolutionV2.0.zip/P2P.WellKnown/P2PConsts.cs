﻿namespace P2P.WellKnown
{
    using System;

    public class P2PConsts
    {
        public const int SRV_PORT = 2280;
    }
}

