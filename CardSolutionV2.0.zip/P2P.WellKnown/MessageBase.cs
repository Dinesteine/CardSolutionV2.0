﻿namespace P2P.WellKnown
{
    using System;

    [Serializable]
    public abstract class MessageBase
    {
        protected MessageBase()
        {
        }
    }
}

