﻿namespace P2P.WellKnown.C2S
{
    using System;

    [Serializable]
    public class MassMsg : MessageBase
    {
    }
}

